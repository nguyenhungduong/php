<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Update</title>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
<?php
    include('control.php'); // gọi trang control
    $get_data = new data_dangky(); // gọi lớp data_giangduong trong control
    $update_dky_id = $get_data->select_dangky_id($_GET['up']); // giá trị truyền từ trang select sang
    $i_sv = mysqli_fetch_assoc($update_dky_id); // Lấy một hàng dữ liệu
?>
<div class="container">
    <div class="container mt-5">
        <h2 class="text-left">Cập nhật thông tin</h2>
        <p>Hãy đăng ký tham gia chương trình của chúng tôi</p>
        <p class="text-danger">*Bắt buộc</p>
        <form method="POST" action="" role="form" method="POST">
            <div class="form-group">
                <h5 for="hoten" class="required">Họ tên <span class="text-danger">*</span></h5>
                <input value="<?php echo $i_sv['hoten']; ?>" type="text" class="form-control typeinput" id="hoten" name="input_hoten" required placeholder="Câu trả lời của bạn.." style="border: none; border-bottom: 1px solid black;">
            </div>
            <div class="form-group">
                <h5 for="email" class="required">Email <span class="text-danger">*</span></h5>
                <input value="<?php echo $i_sv['email']; ?>" placeholder="Câu trả lời của bạn.." type="email" class="form-control" id="email" name="input_email" required style="border: none; border-bottom: 1px solid black;">
            </div>
            <div class="form-group">
                <h5 for="sdt" class="required">Số điện thoại <span class="text-danger">*</span></h5>
                <p>Xin hãy nhập số điện thoại của bạn</p>
                <input value="<?php echo $i_sv['sdt']; ?>" type="tel" class="form-control" id="sdt" name="input_sdt" required placeholder="Câu trả lời của bạn.." style="border: none; border-bottom: 1px solid black;">
            </div>
            <div class="form-group">
                <h5 for="noidung">Nội dung khác</h5>
                <input value="<?php echo $i_sv['ndkhac']; ?>" class="form-control" id="noidung" name="input_noidung" placeholder="Câu trả lời của bạn.." style="border: none; border-bottom: 1px solid black;">
            </div>
            <div class="form-group text-left">
                <input type="submit" name="update" class="btn btn-success" value="Cập nhật">
                <a href="select_data.php" class="btn btn-danger text-right">Huỷ</a>
            </div>
        </form>
    </div>
    </div>
<?php
    if(isset($_POST['update'])) {
        if(empty($_POST['input_hoten']) 
        || empty($_POST['input_email']) 
        || empty($_POST['input_sdt']) 
        || empty($_POST['input_noidung'])) {
            echo "Bạn chưa nhập thông tin";
        } else {
            $update = $get_data->update_dangky(
                $_POST['input_hoten'],
                $_POST['input_email'],
                $_POST['input_sdt'],
                $_POST['input_noidung'],
                $_GET['up']
            );

            if($update) {
                echo "<script>alert('Cập nhật thành công'); window.location='select_data.php'</script>";
            } else {
                echo "<script>alert('Không thực thi được');</script>";
            }
        }
    }
?>
</body>
</html>