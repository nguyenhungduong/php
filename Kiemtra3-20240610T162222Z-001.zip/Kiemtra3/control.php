<?php
    include ('connect.php');
    class data_dangky
    {
        public function insert_dangky($name, $email, $sdt,$ndkhac)
        {
            global $conn;
            $sql ="insert into dangky(hoten,email,sdt,ndkhac)
             values ('$name','$email','$sdt','$ndkhac')";
            $run=mysqli_query($conn,$sql);
            return $run;
        }
        public function select_dangky()
        {
            global $conn;
            $sql = "select * from dangky";
            $run= mysqli_query($conn,$sql);
            return $run;
        }        
        public function delete_dangky($ID_dangky)
        {
            global $conn;
            $sql="delete from dangky where ID_user=$ID_dangky";
            $run=mysqli_query($conn,$sql);
            return $run;
        }
        public function select_dangky_id($id)
        {
            global $conn;
            $sql = "select * from dangky where ID_user = $id";
            $run= mysqli_query($conn,$sql);
            return $run;
        }
        
        public function update_dangky($name, $email, $sdt,$ndkhac, $id)
        {
            global $conn;
            $sql="update dangky set 
                    hoten='$name',
                    email='$email',
                    sdt='$sdt',
                    ndkhac='$ndkhac'
                    where ID_user='$id'";
            $run=mysqli_query($conn,$sql);
            return $run;
        }
        public function select_email($email)
        {
            global $conn;
            $sql = "select email from dangky where email = '$email'";
            $run= mysqli_query($conn,$sql);
            return $run;
        }
    }
    ?>