<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <title>Insert</title>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
<div class="container mt-5">
        <h2 class="text-left">Đăng Ký</h2>
        <p>Hãy đăng ký tham gia chương trình của chúng tôi</p>
        <p class="text-danger">*Bắt buộc</p>
        <form method="POST" action="insert_data.php" role="form" method="POST">
            <div class="form-group">
                <h5 for="hoten" class="required">Họ tên <span class="text-danger">*</span></h5>
                <input type="text" class="form-control typeinput" id="hoten" name="input_hoten" required placeholder="Câu trả lời của bạn.." style="border: none; border-bottom: 1px solid black;">
            </div>
            <div class="form-group">
                <h5 for="email" class="required">Email <span class="text-danger">*</span></h5>
                <input placeholder="Câu trả lời của bạn.." type="email" class="form-control" id="email" name="input_email" required style="border: none; border-bottom: 1px solid black;">
            </div>
            <div class="form-group">
                <h5 for="sdt" class="required">Số điện thoại <span class="text-danger">*</span></h5>
                <p>Xin hãy nhập số điện thoại của bạn</p>
                <input type="tel" class="form-control" id="sdt" name="input_sdt" required placeholder="Câu trả lời của bạn.." style="border: none; border-bottom: 1px solid black;">
            </div>
            <div class="form-group">
                <h5 for="noidung">Nội dung khác</h5>
                <input class="form-control" id="noidung" name="input_noidung" placeholder="Câu trả lời của bạn.." style="border: none; border-bottom: 1px solid black;">
            </div>
            <div class="form-group text-left">
                <input type="submit" name="submit" class="btn btn-success" value="Đăng Ký">
                <a href="select_data.php" class="btn btn-info text-right">Hiển thị</a>
            </div>
        </form>
    </div>
    <?php
        if(isset($_POST['submit'])) //Hàm kiểm tra nút submit
        {
            if(empty($_POST['input_hoten']) 
            || empty($_POST['input_email'])
            || empty($_POST['input_sdt'])
            || empty($_POST['input_noidung']))
            echo "Bạn chưa nhập đủ thông tin";
        }
    ?>
        <?php
        include ('control.php'); //gọi trang php
        $get_data= new data_dangky(); //Gọi lớp data_giangduong trong trang control
        if(isset($_POST['submit']))
        {
            //Kiểm tra xem có tên trong csdl chưa
            $q = $get_data->select_email($_POST['input_email']);
            //Nếu đã tồn tại thì thông báo
            if (mysqli_num_rows($q) >0){
                echo "
                <script>
                    alert('Email này đã tồn tại. Vui lòng chọn Email khác!');
                </script>";
                exit;
            }
            $in_sv =$get_data -> insert_dangky($_POST['input_hoten']
            ,$_POST['input_email']
            ,$_POST['input_sdt']
            ,$_POST['input_noidung']);
            if($in_sv) 
            echo "<script>
                    alert('Thành công');
                </script>";
            else 
            echo "<script>alert('Không thực thi được')</script>";                
        }
    ?>
</body>

</html>