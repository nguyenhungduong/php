document.getElementById("huy").addEventListener("click", function (event) {
    event.preventDefault(); // Ngăn chặn việc tải lại trang
    window.location='select_data.php'
  });
