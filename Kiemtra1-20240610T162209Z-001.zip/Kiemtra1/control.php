<?php
    include ('connect.php');
    class data_sanpham
    {
        public function insert_shop($name, $gia, $giakm, 
        $nhasanxuat, $picture, $mausac, $tinhnang)
        {
            global $conn;
            $sql ="insert into sanpham(tensanpham,gia,giakm,nhasanxuat,hinhsanpham,mausac,tinhnang)
             values ('$name','$gia','$giakm','$nhasanxuat','$picture','$mausac', '$tinhnang')";
            $run=mysqli_query($conn,$sql);
            return $run;
        }
        public function select_shop()
        {
            global $conn;
            $sql = "select * from sanpham";
            $run= mysqli_query($conn,$sql);
            return $run;
        }        
        public function delete_shop($ID_sanpham)
        {
            global $conn;
            $sql="delete from sanpham where ID_sanpham=$ID_sanpham";
            $run=mysqli_query($conn,$sql);
            return $run;
        }
        public function select_shop_id($id)
        {
            global $conn;
            $sql = "select * from sanpham where ID_sanpham = $id";
            $run= mysqli_query($conn,$sql);
            return $run;
        }
        
        public function update_shop($name, 
        $gia, $giakm, 
        $nhasanxuat, $picture, 
        $mausac, $tinhnang,$id)
        {
            global $conn;
            $sql="update sanpham set 
                    tensanpham='$name',
                    gia='$gia',
                    giakm='$giakm',
                    nhasanxuat='$nhasanxuat',
                    hinhsanpham='$picture',
                    mausac='$mausac',
                    tinhnang='$tinhnang'
                    where ID_sanpham='$id'";
            $run=mysqli_query($conn,$sql);
            return $run;
        }
        
    }
    ?>