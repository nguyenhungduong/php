<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Update</title>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
<?php
    include('control.php'); // gọi trang control
    $get_data = new data_sanpham(); // gọi lớp data_giangduong trong control
    $update_shop_id = $get_data->select_shop_id($_GET['up']); // giá trị truyền từ trang select sang
    $i_sv = mysqli_fetch_assoc($update_shop_id); // Lấy một hàng dữ liệu
?>
    <div class="container">
        <h1>CẬP NHẬT SẢN PHẨM</h1>
        <hr>
        <table class="table border table-dark">
        <form method="POST" action="" role="form" enctype="multipart/form-data" style="padding: 20px;">
                <tr>
                    <td><label for="name">Tên sản phẩm:</label></td>
                    <td><input class="form-control" type="text" value="<?php echo $i_sv['tensanpham']; ?>" name="name" required></td>
                </tr>
                <tr>
                    <td><label for="gia">Giá:</label></td>
                    <td><input class="form-control" type="number" value="<?php echo $i_sv['gia']; ?>" name="gia" required></td>
                </tr>
                <tr>
                    <td><label for="giakm">Giá KM:</label></td>
                    <td><input class="form-control" type="number" value="<?php echo $i_sv['giakm']; ?>" name="giakm" required></td>
                </tr>
                <tr>
                    <td><label for="nhasanxuat">Nhà sản xuất:</label></td>
                    <td>
                        <select class="form-control" name="nhasanxuat">
                            <option value="<?php echo $i_sv['nhasanxuat']; ?>"><?php echo $i_sv['nhasanxuat']; ?></option>
                            <option value="Việt Nam">Việt Nam</option>
                            <option value="Mỹ">Mỹ</option>
                            <option value="Pháp">Pháp</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><label for="picture">Hình sản phẩm</label></td>
                    <td>
                        Before: <img class="m-3" style="max-width: 70px; height: auto" src="upload/<?php echo $i_sv['hinhsanpham']; ?>" alt="">
                        Preview: <img class="m-3" style="max-width: 70px; height: auto" id="preview" src="" alt="">
                        <input class="form-control" id="file-input" type="file" name="picture">
                    </td>
                </tr>
                <tr>
                    <td><label for="mausac">Màu sắc:</label></td>
                    <td>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="color" value="Đỏ" id="colorRed" <?php if($i_sv['mausac'] == 'Đỏ') echo 'checked'; ?>>
                            <label class="form-check-label" for="colorRed">Đỏ</label>
                        </div>
                        <div class="form-check form-check-inline mx-3">
                            <input class="form-check-input" type="radio" name="color" value="Xanh" id="colorBlue" <?php if($i_sv['mausac'] == 'Xanh') echo 'checked'; ?>>
                            <label class="form-check-label" for="colorBlue">Xanh</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="color" value="Trắng" id="colorWhite" <?php if($i_sv['mausac'] == 'Trắng') echo 'checked'; ?>>
                            <label class="form-check-label" for="colorWhite">Trắng</label>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td><label for="tinhnang">Tính năng:</label></td>
                    <td>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="tinhnang[]" value="GPS" id="featureGPS" <?php if(strpos($i_sv['tinhnang'], 'GPS') !== false) echo 'checked'; ?>>
                            <label class="form-check-label" for="featureGPS">GPS</label>
                        </div>
                        <div class="form-check form-check-inline mx-3">
                            <input class="form-check-input" type="checkbox" name="tinhnang[]" value="WIFI 6" id="featureWIFI6" <?php if(strpos($i_sv['tinhnang'], 'WIFI 6') !== false) echo 'checked'; ?>>
                            <label class="form-check-label" for="featureWIFI6">WIFI 6</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="tinhnang[]" value="Jack 3.5" id="featureJack35" <?php if(strpos($i_sv['tinhnang'], 'Jack 3.5') !== false) echo 'checked'; ?>>
                            <label class="form-check-label" for="featureJack35">Jack 3.5</label>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <div class="text-right">
                            <a href="select_data.php" class="btn btn-primary" type="button">Hiển thị</a>
                            <a href="select_data.php" class="btn btn-danger mx-2">Hủy</a>
                            <input class="btn btn-primary" type="submit" name="update" value="Cập nhật">
                        </div>
                    </td>
                </tr>
        </form>
        </table>
        <script>
            document.getElementById("file-input").addEventListener("change", function () {
                var fileInput = document.getElementById("file-input");
                var imageURL = URL.createObjectURL(fileInput.files[0]);
                var previewImage = document.getElementById("preview");
                previewImage.src = imageURL;
            });
        </script>
    </div>
<?php
    if(isset($_POST['update'])) {
        if(empty($_POST['name']) || empty($_POST['gia']) || empty($_POST['giakm']) || empty($_POST['color'])) {
            echo "Bạn chưa nhập thông tin";
        } else {
            $check = implode(", ", $_POST['tinhnang']);
            $picture_name = $_FILES['picture']['name'];

            if(!empty($picture_name)) {
                move_uploaded_file($_FILES['picture']['tmp_name'], 'upload/' . $picture_name);
            } else {
                $picture_name = $i_sv['hinhsanpham']; // Sử dụng hình ảnh cũ nếu không tải lên hình mới
            }

            $update = $get_data->update_shop(
                $_POST['name'],
                $_POST['gia'],
                $_POST['giakm'],
                $_POST['nhasanxuat'],
                $picture_name,
                $_POST['color'],
                $check,
                $_GET['up']
            );

            if($update) {
                echo "<script>alert('Cập nhật thành công'); window.location='select_data.php'</script>";
            } else {
                echo "<script>alert('Không thực thi được');</script>";
            }
        }
    }
?>
</body>
</html>