<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <title>DANHSACH</title>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
    <div class="container">
<h1>DANH SÁCH ĐĂNG KÝ</h1>
<a class="btn btn-primary" href="insert_data.php">Thêm mới</a><hr>
    <?php
        include "control.php";//Goi den trang
        $get_data= new data_sanpham();//Goi den lop
        $select_product = $get_data->select_shop();//Goi den function
    ?>
    <table class="container-fluid table border table-dark">
        <tr>
            <th>Tên sản phẩm</th>
            <th>Giá</th>
            <th>Giá KM</th>
            <th>Nhà sản xuất</th>
            <th>Hình ảnh</th>
            <th>Màu sắc</th>
            <th>Tính năng</th>
            <th colspan="2">Tùy chọn</th>
        </tr>
        <?php
            foreach ($select_product as $i_sv)//Duyệt dữ liệu trả về
            {
        ?>
        <tr>
            <td><?php echo $i_sv['tensanpham']?></td>
            <td><?php echo $i_sv['gia']?></td>
            <td><?php echo $i_sv['giakm']?></td>
            <td><?php echo $i_sv['nhasanxuat']?></td>
            <td><img src="upload/<?php echo $i_sv['hinhsanpham']?>" alt="" style="max-width: 50px; height: auto"></td>
            <td><?php echo $i_sv['mausac']?></td>
            <td><?php echo $i_sv['tinhnang']?></td>
            <td><a class="btn btn-primary" href="update_data.php?up=<?php echo $i_sv['ID_sanpham']?>">Update</td>
            <td><a class="btn btn-danger" href="delete_data.php?del=<?php echo $i_sv['ID_sanpham']?>"
                onclick="if(confirm('Bạn có chắc chắn xóa')) return true;
                else return false";>Delete</td>
        </tr>
        <?php
            }
        ?>
    </table>
    <script>
      document.getElementById("themmoi").addEventListener("click", function (event) {
        event.preventDefault(); // Ngăn chặn việc tải lại trang
        window.location='insert_data.php'
    });
  </script>
  </div>
</body>
</html>