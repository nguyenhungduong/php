<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <title>Insert</title>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
    <div class="container">
        <h1>THÊM SẢN PHẨM</h1>
        <hr>
        <table class="table border table-dark">
        <form method="POST" action="insert_data.php" role="form" enctype="multipart/form-data" style="padding: 20px;">
        <tr>
            <td><label for="name">Tên sản phẩm:</label></td>
            <td><input  class="form-control" type="text" name="name" required></td>
        </tr>
        <tr>
            <td><label for="code">Giá:</label></td>
            <td> <input  class="form-control" type="number" name="gia" required></td>
        </tr>
        <tr>
            <td><label for="money">Giá KM:</label></td>
            <td><input class="form-control" type="number" name="giakm"></td>
        </tr>
        <tr>
            <td><label for="category">Nhà sản xuất:</label></td>
            <td>
            <select class="form-control" name="nhasanxuat">
                <option value="">Chọn nhà sản xuất</option>
                <option value="Việt Nam">Việt Nam</option>
                <option value="Mỹ">Mỹ</option>
                <option value="Pháp">Pháp</option>
            </select>
            </td>
        </tr>
        <tr>
            <td><label for="picture">Hình sản phẩm</label></td>
            <td>
                Preview: <img class="m-3" style="max-width: 70px; height: auto" id="preview" src="" alt="">
                <input class="form-control" id="file-input" type="file" name="picture">
            </td>
        </tr>
        <script>
            document.getElementById("file-input").addEventListener("change", function () {
                var fileInput = document.getElementById("file-input");
                var imageURL = URL.createObjectURL(fileInput.files[0]);
                var previewImage = document.getElementById("preview");
                previewImage.src = imageURL;
            });
        </script>
        <tr>
            <td><label for="color">Màu sắc:</label></td>
            <td>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="color" id="colorRed" value="Đỏ">
                    <label class="form-check-label" for="colorRed">Đỏ</label>
                </div>
                <div class="form-check form-check-inline mx-3">
                    <input class="form-check-input" type="radio" name="color" id="colorBlue" value="Xanh">
                    <label class="form-check-label" for="colorBlue">Xanh</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="color" id="colorWhite" value="Trắng">
                    <label class="form-check-label" for="colorWhite">Trắng</label>
                </div>
            </td>
        </tr>
        <tr>
            <td><label for="tinhnang">Tính năng:</label></td>
            <td>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="tinhnang[]" id="featureGPS" value="GPS">
                    <label class="form-check-label" for="featureGPS">GPS</label>
                </div>
                <div class="form-check form-check-inline mx-3">
                    <input class="form-check-input" type="checkbox" name="tinhnang[]" id="featureWIFI6" value="WIFI 6">
                    <label class="form-check-label" for="featureWIFI6">WIFI 6</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="tinhnang[]" id="featureJack35" value="Jack 3.5">
                    <label class="form-check-label" for="featureJack35">Jack 3.5</label>
                </div>
            </td>
        </tr>   
        <tr>
            <td colspan="2">
                <div class="text-right">
                <input class="btn btn-primary" type="submit" name="submit" value="Thêm sản phẩm">
                        <a href="select_data.php" class="btn btn-primary" type="buton">Hiển thị</a>
                </div>
            </td>
        </tr>
    </form>
</table>
    <?php
        if(isset($_POST['submit'])) //Hàm kiểm tra nút submit
        {
            if(empty($_POST['name']) 
            || empty($_POST['gia'])
            || empty($_POST['giakm'])
            || empty($_POST['nhasanxuat'])
            || empty($_POST['color']))
            echo "Bạn chưa nhập đủ thông tin";
            else
            {
                echo "<br>Name product: ".$_POST['name'].
                "<br>Code product: ".$_POST['gia'].
                "<br>giakm: ".$_POST['giakm'].
                "<br>nhasanxuat: ".$_POST['nhasanxuat'].
                "<br>color: ".$_POST['color'];
                // "<br>color: ".$_POST['tinhnang'];
                // "<br>Picture: ".$_POST['picture'];
            }
        }
    ?>
        <?php
        $check="";//gan chuoi la rong
        foreach($_POST['tinhnang'] as $icheck)
        {
            $check.=$icheck.", ";//duyet mang
        }
        include ('control.php'); //gọi trang php
        $get_data= new data_sanpham(); //Gọi lớp data_giangduong trong trang control
        if(isset($_POST['submit']))
        {
            move_uploaded_file($_FILES['picture']['tmp_name'],'upload/'.$_FILES['picture']['name']);
            $in_sv =$get_data -> insert_shop($_POST['name']
            ,$_POST['gia']
            ,$_POST['giakm']
            ,$_POST['nhasanxuat']
            ,$_FILES['picture']['name']
            ,$_POST['color']
            ,$check);
            if($in_sv) echo "<script>alert('Thành công');
                            </script>";
            else 
            echo "<script>alert('Không thực thi được')</script>";                
        }
    ?>
</body>
<script src="script.js"></script>
</html>