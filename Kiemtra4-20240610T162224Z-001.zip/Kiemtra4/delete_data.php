<?php
   include ('control.php'); // gọi trang control
   $get_data= new data_sanpham(); // gọi lớp data_giangduong trong control
   $del=$get_data->delete_sanpham($_GET['del']);
   if($del) echo "<script>alert('Bạn đã xóa thành công');
               window.location='select_data.php'</script>";
    else echo "<script>alert(' Bạn không xóa được') </script>";
                        
?>
