<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Update</title>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
<?php
    include('control.php'); // gọi trang control
    $get_data = new data_sanpham(); // gọi lớp data_giangduong trong control
    $update_shop_id = $get_data->select_sanpham_id($_GET['up']); // giá trị truyền từ trang select sang
    $i_sv = mysqli_fetch_assoc($update_shop_id); // Lấy một hàng dữ liệu
?>
<div class="container">
    <h1>CẬP NHẬT SẢN PHẨM</h1>
    <hr>
    <table class="table border table-info table-hover">
    <form method="POST" action="" role="form" enctype="multipart/form-data" style="padding: 20px;">
        <tr>
            <td><label for="name">Tên sản phẩm:</label></td>
            <td><input class="form-control" type="text" value="<?php echo $i_sv['tensanpham']; ?>" name="input_ten" required></td>
        </tr>
        <tr>
            <td><label for="code">Mô tả:</label></td>
            <td><textarea name="textarea_mota" id="" class="form-control" required><?php echo $i_sv['mota']; ?></textarea></td>
        </tr>
        <tr>
            <td><label for="money">Số lượng sản phẩm:</label></td>
            <td><input value="<?php echo $i_sv['soluong']; ?>" class="form-control" type="number" name="input_soluong"></td>
        </tr>
        <tr>
            <td><label for="money">Giá sản phẩm:</label></td>
            <td><input value="<?php echo $i_sv['gia']; ?>" class="form-control" type="number" name="input_gia"></td>
        </tr>
        <tr>
            <td><label for="category">Loại sản phẩm:</label></td>
            <td>
            <select class="form-control" name="select_loai">
                <option value="<?php echo $i_sv['loai']; ?>"><?php echo $i_sv['loai']; ?></option>
                <option value="Điện tử">Điện tử</option>
                <option value="Gia dụng">Gia dụng</option>
                <option value="Trái cây">Trái cây</option>
            </select>
            </td>
        </tr>
        <tr>
            <td><label for="picture">Hình sản phẩm</label></td>
            <td>
                <input class="form-control" id="file-input" type="file" name="picture">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Before</h6>
                        <img src="upload/<?php echo $i_sv['picture']; ?>" alt="" style="max-width: 70px; height: auto">
                    </div>
                    <div class="col-md-6">
                        <h6>Preview</h6>
                        <img id="preview" src="" alt="" style="max-width: 70px; height: auto">
                    </div>
                </div>
            </td>
        </tr>
        <script>
            document.getElementById("file-input").addEventListener("change", function () {
                var fileInput = document.getElementById("file-input");
                var imageURL = URL.createObjectURL(fileInput.files[0]);
                var previewImage = document.getElementById("preview");
                previewImage.src = imageURL;
            });
        </script>

                <tr>
                    <td colspan="2">
                        <div class="text-right">
                            <a href="select_data.php" class="btn btn-primary" type="button">Hiển thị</a>
                            <a href="select_data.php" class="btn btn-danger mx-2">Hủy</a>
                            <input class="btn btn-primary" type="submit" name="update" value="Cập nhật">
                        </div>
                    </td>
                </tr>
        </form>
        </table>
        <script>
            document.getElementById("file-input").addEventListener("change", function () {
                var fileInput = document.getElementById("file-input");
                var imageURL = URL.createObjectURL(fileInput.files[0]);
                var previewImage = document.getElementById("preview");
                previewImage.src = imageURL;
            });
        </script>
    </div>
<?php
    if(isset($_POST['update'])) {
        if(empty($_POST['input_ten']) 
        || empty($_POST['input_soluong']) 
        || empty($_POST['textarea_mota']) 
        || empty($_POST['input_gia'])) {
            echo "Bạn chưa nhập thông tin";
        } else {
            $picture_name = $_FILES['picture']['name'];
            if(!empty($picture_name)) {
                move_uploaded_file($_FILES['picture']['tmp_name'], 'upload/' . $picture_name);
            } else {
                $picture_name = $i_sv['picture']; // Sử dụng hình ảnh cũ nếu không tải lên hình mới
            }

            $update = $get_data->update_sanpham(
                $_POST['input_ten'],
                $_POST['textarea_mota'],
                $_POST['input_soluong'],
                $_POST['input_gia'],
                $_POST['select_loai'],
                $picture_name,
                $_GET['up']
            );

            if($update) {
                echo "<script>alert('Cập nhật thành công'); window.location='select_data.php'</script>";
            } else {
                echo "<script>alert('Không thực thi được');</script>";
            }
        }
    }
?>
</body>
</html>