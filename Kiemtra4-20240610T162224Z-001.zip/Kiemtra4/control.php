<?php
    include ('connect.php');
    class data_sanpham
    {
        public function insert_sanpham($name, $mota, $soluong, 
        $gia, $loai, $picture)
        {
            global $conn;
            $sql ="insert into banhang(tensanpham,mota,soluong,gia,loai,picture)
             values ('$name','$mota','$soluong','$gia','$loai','$picture')";
            $run=mysqli_query($conn,$sql);
            return $run;
        }
        public function select_sanpham()
        {
            global $conn;
            $sql = "select * from banhang";
            $run= mysqli_query($conn,$sql);
            return $run;
        }        
        public function delete_sanpham($ID_sanpham)
        {
            global $conn;
            $sql="delete from banhang where ID_product=$ID_sanpham";
            $run=mysqli_query($conn,$sql);
            return $run;
        }
        public function select_sanpham_id($id)
        {
            global $conn;
            $sql = "select * from banhang where ID_product = $id";
            $run= mysqli_query($conn,$sql);
            return $run;
        }
        
        public function update_sanpham($name, 
        $mota, $soluong, 
        $gia, $loai, $picture, $id)
        {
            global $conn;
            $sql="update banhang set 
                    tensanpham='$name',
                    mota='$mota',
                    soluong='$soluong',
                    gia='$gia',
                    loai='$loai',
                    picture='$picture'
                    where ID_product='$id'";
            $run=mysqli_query($conn,$sql);
            return $run;
        }
        public function select_tensanpham($ten)
        {
            global $conn;
            $sql = "select tensanpham from banhang where tensanpham = '$ten'";
            $run= mysqli_query($conn,$sql);
            return $run;
        }
    }
    ?>