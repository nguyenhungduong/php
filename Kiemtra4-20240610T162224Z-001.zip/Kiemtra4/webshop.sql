-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost
-- Thời gian đã tạo: Th5 22, 2024 lúc 11:54 AM
-- Phiên bản máy phục vụ: 10.4.28-MariaDB
-- Phiên bản PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `webshop`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `banhang`
--

CREATE TABLE `banhang` (
  `ID_product` int(10) NOT NULL,
  `tensanpham` varchar(150) NOT NULL,
  `mota` varchar(150) NOT NULL,
  `soluong` int(100) NOT NULL,
  `gia` float NOT NULL,
  `loai` varchar(100) NOT NULL,
  `picture` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `banhang`
--

INSERT INTO `banhang` (`ID_product`, `tensanpham`, `mota`, `soluong`, `gia`, `loai`, `picture`) VALUES
(2, '645645', 'oiuoiu', 9, 8797, 'Gia dụng', '08e83bebd2bd797ec70aeeed453a4dcf.jpeg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `shopvanvan`
--

CREATE TABLE `shopvanvan` (
  `ID_product` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `code` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `money` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `picture` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `shopvanvan`
--

INSERT INTO `shopvanvan` (`ID_product`, `name`, `code`, `category`, `money`, `description`, `picture`) VALUES
(2, 'Flower', '3421', 'USA', '30000', 'hhhhhhh', ''),
(10, 'Flower', '3421', 'NewDiland', '30000', 'ergterger', 'six.png'),
(11, 'dsd', 'asdsad', 'NewDiland', '3212312', 'sadasdasd', '15prm.png'),
(13, 'Flower', 'sfsfs', 'NewDiland', '4331', 'ergterger', '3m31mb.png'),
(17, '1111', '1111', 'NewDiland', '11111', '111111', '0-phantram.png');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `banhang`
--
ALTER TABLE `banhang`
  ADD PRIMARY KEY (`ID_product`);

--
-- Chỉ mục cho bảng `shopvanvan`
--
ALTER TABLE `shopvanvan`
  ADD PRIMARY KEY (`ID_product`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `banhang`
--
ALTER TABLE `banhang`
  MODIFY `ID_product` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `shopvanvan`
--
ALTER TABLE `shopvanvan`
  MODIFY `ID_product` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
