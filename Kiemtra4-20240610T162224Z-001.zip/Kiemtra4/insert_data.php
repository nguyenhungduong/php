<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <title>Insert</title>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
    <div class="container">
        <h1>THÊM SẢN PHẨM</h1>
        <hr>
        <table class="table border table-info table-hover table-sm">
        <form method="POST" action="insert_data.php" role="form" enctype="multipart/form-data" style="padding: 20px;">
        <tr>
            <td><label for="name">Tên sản phẩm:</label></td>
            <td><input  class="form-control" type="text" name="input_ten" required></td>
        </tr>
        <tr>
            <td><label for="code">Mô tả:</label></td>
            <td><textarea name="textarea_mota" id="" class="form-control" required></textarea></td>
        </tr>
        <tr>
            <td><label for="money">Số lượng sản phẩm:</label></td>
            <td><input class="form-control" type="number" name="input_soluong"></td>
        </tr>
        <tr>
            <td><label for="money">Giá sản phẩm:</label></td>
            <td><input class="form-control" type="number" name="input_gia"></td>
        </tr>
        <tr>
            <td><label for="category">Loại sản phẩm:</label></td>
            <td>
            <select class="form-control" name="select_loai">
                <option value="">-- Chọn loại sản phẩm --</option>
                <option value="Điện tử">Điện tử</option>
                <option value="Gia dụng">Gia dụng</option>
                <option value="Trái cây">Trái cây</option>
            </select>
            </td>
        </tr>
        <tr>
            <td><label for="picture">Hình sản phẩm</label></td>
            <td>
                Preview: <img class="m-3" style="max-width: 70px; height: auto" id="preview" src="" alt="">
                <input class="form-control" id="file-input" type="file" name="picture">
            </td>
        </tr>
        <script>
            document.getElementById("file-input").addEventListener("change", function () {
                var fileInput = document.getElementById("file-input");
                var imageURL = URL.createObjectURL(fileInput.files[0]);
                var previewImage = document.getElementById("preview");
                previewImage.src = imageURL;
            });
        </script>
        <tr>
            <td colspan="2">
                <div class="text-right">
                <input class="btn btn-success" type="submit" name="submit" value="Thêm sản phẩm">
                <a href="select_data.php" class="btn btn-primary" type="buton">Hiển thị</a>
                </div>
            </td>
        </tr>
    </form>
</table>
    <?php
        if(isset($_POST['submit'])) //Hàm kiểm tra nút submit
        {
            if(empty($_POST['input_ten']) 
            || empty($_POST['textarea_mota'])
            || empty($_POST['input_soluong'])
            || empty($_POST['input_gia'])
            || empty($_POST['select_loai']))
            echo "Bạn chưa nhập đủ thông tin";
            else
            {
                // echo "<br>Name product: ".$_POST['name'].
                // "<br>Code product: ".$_POST['gia'].
                // "<br>giakm: ".$_POST['giakm'].
                // "<br>nhasanxuat: ".$_POST['nhasanxuat'].
                // "<br>color: ".$_POST['color'];
                // "<br>color: ".$_POST['tinhnang'];
                // "<br>Picture: ".$_POST['picture'];
            }
        }
    ?>
        <?php
        include ('control.php'); //gọi trang php
        $get_data= new data_sanpham(); //Gọi lớp data_giangduong trong trang control
        if(isset($_POST['submit']))
        {
            //Kiểm tra xem có tên trong csdl chưa
            $q = $get_data->select_tensanpham($_POST['input_ten']);
            //Nếu đã tồn tại thì thông báo
            if (mysqli_num_rows($q) >0){
                echo "<br> Tên sản phẩm này đã tồn tại. Vui lòng chọn tên khác!";
                exit;
            }

            move_uploaded_file($_FILES['picture']['tmp_name'],'upload/'.$_FILES['picture']['name']);
            $in_sv =$get_data -> insert_sanpham($_POST['input_ten']
            ,$_POST['textarea_mota']
            ,$_POST['input_soluong']
            ,$_POST['input_gia']
            ,$_POST['select_loai']
            ,$_FILES['picture']['name']);
            if($in_sv) 
            echo "<script>
                    alert('Thành công');
                </script>";
            else 
            echo "<script>alert('Không thực thi được')</script>";                
        }
    ?>
</body>

</html>